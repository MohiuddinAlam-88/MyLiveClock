MY LIVE CLOCK - Android APK project

Features:
- Live analog clock with moving hour/minute/second hands
- Digital clock with 12/24-hour toggle
- Live date and weekday
- Bangladesh and Malta clocks
- Malta daylight-saving time handled automatically
- Works offline using the phone's clock and time-zone database

AUTOMATIC APK BUILD USING GITHUB (no Android Studio needed):
1. Sign in to GitHub and create a new empty repository.
2. Extract this ZIP on your computer.
3. Upload all files and folders INSIDE the MyLiveClock folder to the repository.
   Make sure the .github/workflows/build-apk.yml file is included.
4. Open the repository's Actions tab.
5. Select "Build My Live Clock APK" and press "Run workflow" (or wait for the push build).
6. When the run finishes successfully, open that run and download the
   "MyLiveClock-debug-apk" artifact.
7. Extract the downloaded artifact ZIP. It contains app-debug.apk.
8. Send app-debug.apk to your Android phone and install it. Allow "Install unknown apps"
   for the app you use to open the APK, if Android asks.

LOCAL BUILD (Android Studio):
Open this folder in Android Studio, let Gradle sync, then choose
Build > Build Bundle(s) / APK(s) > Build APK(s).

Package: com.myliveclock.app
Minimum Android: 6.0 (API 23)
This ZIP contains source and an automated build workflow; it is not itself a compiled APK.
